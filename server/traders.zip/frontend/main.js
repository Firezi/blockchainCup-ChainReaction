let graphic = false;
  
const genTable = data => {
  console.log(data);
  let elementHtml = 
`
<table>
  <thead>
    <tr>
      <th data-order="top_position">#</th>
      <th data-order="name">Трейдер</th>
      <th data-order="profit">Доходность</th>
      <th data-order="recovery">Возвратность</th>
      <th data-order="dropdown">Максимальная просадка</th>
      <th></th>
    </tr>
  </thead>
  <tbody>`;
  for (let trader of data) {
    elementHtml += 
`<tr>
  <td>${trader.top_position}</td>
  <td>${trader.name}</td>
  <td>${trader.profit}</td>
  <td>${trader.recovery}</td>
  <td>${trader.dropdown}</td>
  <td class="trader-about-btn waves-effect waves-light btn red" data-trader=${trader.id}>Узнать больше</td>
</tr>`;
  }
  elementHtml += 
`  </tbody>
</table>`;
  $('#result').html(elementHtml);
  $('.trader-about-btn').click(function() {
    $.get(`./trader?trader=${this.dataset.trader}`, (results) => {
      renderTrader(JSON.parse(results));
    });
  });
  $('thead th').click(function() {
    $.get(`./traders?order=${this.dataset.order}`, (traders) => {
      genTable(JSON.parse(traders));
    });
  });
}


const translates = {
  recovery_factor: 'Возвратность',
  payoff_ratio: 'Profit ratio',
  profit_factor: 'Доходность',
  max_dropdown: 'Максимальная просадка',
  average_profit_percent: 'Средняя доходность',
  percent_winning: 'Percent winning',
  profit_per_bar: 'Прибыль за свечу'
}

const colors = [
  '#d70206',
  '#f05b4f',
  '#f4c63d',
  '#d17905',
  '#453d3f',
  '#59922b',
  '#0544d3'
]


let currentTraderResults = [];
const renderTrader = trader => {
  $('#result').html();
  $('article').css('display', 'none');
  let labels = '';
  let i = 0;
  for (let metric in trader.results[0]) {
    if (metric !== 'date') {
       labels += 
       `<label class="filter-checkbox-container">
         <input data-metric=${metric} type="checkbox" class="filled-in red" ${'checked'}>
         <span>
           ${translates[metric] !== undefined ? translates[metric] : metric}
            
         </span>
         <span class="line-label"></span>
      </label>`;
      if (i % 2 != 0) 
        labels += '<br>';
      i++;
    }
  }
  let elementHtml = 
  `
  <h2 class="trader-title"><i class="material-icons medium">person</i> ${trader.name}</h2>
  <div class="ct-chart ct-perfect-fourth"></div>
  <div id="metrics-filters">
    ${labels}
  </div>
  <div class="trader-description">
    ${trader.description}
  </div>
  <a href="${trader.url}">
    <div class="trader-contact right btn waves-effect waves-light red">Contact trader now <i class="material-icons right">send</i></div>
  </a>`;
  $('#result').html(elementHtml);
  $('#metrics-filters input').change(function() {
    drowGraphics();
  });
  currentTraderResults = trader.results;
  drowGraphics();
}

const drowGraphics = () => {
  const results = currentTraderResults; 
  let labels = [];
  let series = [];
  for (let result of results) {
    // labels.push();
    let i = 0;
    for (let k in result) {
      if (k === 'data') {
        result.date.substr(0, result.date.indexOf('T'));
      } else {
        console.log(k);
        if ($(`#metrics-filters input[data-metric=${k}]`).prop('checked')) {
          if (series[i] === undefined)
            series[i] = [result[k]];
          else
            series[i].push(result[k]);
          i++;
        }
      }
    }
  }
  const data = {
    labels,
    series
  };
  const options = {
    showArea: true,
    showPoint: false,
    low: 0,
    fullWidth: true
  };
  if (!graphic) {
    graphic = new Chartist.Line('.ct-chart', data, options);
    graphic.on('draw', function(data) {
      if(data.type === 'line' || data.type === 'area') {
        data.element.animate({
          d: {
            begin: 500 * data.index,
            dur: 500,
            from: data.path.clone().scale(1, 0).translate(0, data.chartRect.height()).stringify(),
            to: data.path.clone().stringify(),
            easing: Chartist.Svg.Easing.easeOutQuint
          }
        });
      }
      if(data.type === 'line') {
        console.log($(`#metrics-filters input:checked`)[data.index]);
        $($($(`#metrics-filters input:checked`)[data.index]).parent().find('.line-label')).css('background', colors[data.index]);
      }
    });
  } else {
    $('.line-label').css('background', 'white');
    graphic.update(data, options);
  }
}

$.get('./traders', (traders) => {
  genTable(JSON.parse(traders));
});

/*$.get(`./trader?trader=0`, (results) => {
  renderTrader(JSON.parse(results));
});*/


/*renderTrader({
  name: 'Very cool trader',
  contact: 'http://google.com',
  results: [
    {date: '01-01-2018', profit: 1000},
    {date: '01-02-2018', profit: 1200},
    {date: '01-03-2018', profit: 1500},
    {date: '01-04-2018', profit: 1300},
    {date: '01-05-2018', profit: 1000},
    {date: '01-05-2018', profit: 3000},
    {date: '01-05-2018', profit: 10},
  ]
});*/
/*genTable([{
  name: 'Very Good Trader #1',
  profit: '100$',
  id: 11
}, {
  name: 'Very Good Trader #1',
  profit: '100$',
  id: 11
}, {
  name: 'Very Good Trader #1',
  profit: '100$',
  id: 11
}, {
  name: 'Very Good Trader #1',
  profit: '100$',
  id: 11
}]);*/