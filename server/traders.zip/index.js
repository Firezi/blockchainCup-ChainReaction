const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const mysql      = require('mysql');
const db = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'traders'
});
 
db.connect();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(express.static('frontend'));

app.get('/traders', (req, res) => {
  let order = req.query.order;
  console.log(req.query);
  if (order !== 'name' && order !== 'profit' && order !== 'recovery' && order !== 'dropdown')
    order = 'top_position';
  console.log(order);
  db.query(`select * from traders order by  ${order} ASC`, (err, data) => {
    if (err) {
      res.status(503);
      res.end();
    } else {
      let list = [];
      for (let trader of data) {
        list.push(trader);
      }
      res.status(200);
      res.end(JSON.stringify(list));
    }
  });
});
app.get('/trader', (req, res) => {
  const traderId = req.query.trader * 1;
  if (typeof traderId !== 'number') {
    console.log(traderId);
    res.status(503);
    res.end();
  } else {
    db.query(`select * from traders where id = ${traderId}`, (err, data) => {
      if (err) {
        res.status(503);
        res.end();
      } else {
        const trader = data[0];
        db.query(`select * from traders_results where trader_id = ${traderId}`, (err, data) => {
          if (err) {
            res.status(503);
            res.end();
          } else {
            let list = [];
            console.log(data);
            for (let trader of data) {
              list.push({});
              for (let metric in trader) {
                if (metric !== 'trader_id') {
                  list[list.length - 1][metric] = trader[metric]
                }
              }
            }
            res.status(200);
            trader.results = list;
            res.end(JSON.stringify(trader));
          }
        });
      }
    });
  }
});

app.listen(3000);